Author: Zixia Weng
UID: 305029822
Content: Project #2 CS246
Email: zixia@g.ucla.edu